/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package bd.circle;
import java.util.Scanner;
/**
 *
 * @author PROJET NDAGANO
 */
public class Question2 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the radius of the circle: ");
        double radius = scanner.nextDouble();
        Circle circle = new Circle(radius);// we have to connect the Circle class with the main class
        circle.displayResults();
    }}

