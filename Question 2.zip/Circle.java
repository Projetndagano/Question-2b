/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bd.circle;
 

/**
 *
 * @author PROJET NDAGANO
 */
public class Circle {
 //declaring our variables, i have put double coz the number can be an undecimal number
    double radius;
    double area;
    double circumference;

    public Circle(double radius) // i put just integer raduis cause this is actualy what we want to calculate
    {
        this.radius = radius;
        this.area = calculateArea();
        this.circumference = calculateCircumference();
    }

    private double calculateArea() 
    {
        return Math.PI * radius * radius;
    }

    private double calculateCircumference() {
        return 2 * Math.PI * radius;
    }

    public void displayResults() // the message that will be displayed
    {
        System.out.println("The radius is : " + radius);
        System.out.println("Area: " + area);
        System.out.println("Circumference: " + circumference);
    }
}

 

